class GeometricObject{
	public double area;
	public double getArea(){
		return(area);
	}
}

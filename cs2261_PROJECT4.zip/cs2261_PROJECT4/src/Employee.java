public class Employee extends Person{
		public String office;
		public double salary;
		
		//employee method
		public Employee(String name, String address, String phone, String email) {
		super(name, address, phone, email);
		}	
}

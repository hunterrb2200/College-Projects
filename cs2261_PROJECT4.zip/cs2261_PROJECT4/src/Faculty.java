public class Faculty extends Employee{
	public String officeHours;
	public int rank;

	//faculty method
	public Faculty(String name, String address, String phone, String email) {
	super(name, address, phone, email);
	}
}

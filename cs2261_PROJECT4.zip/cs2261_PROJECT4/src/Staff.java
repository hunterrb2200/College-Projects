public class Staff extends Employee{
	public String title;
	
	//staff method
	public Staff(String name, String address, String phone, String email) {
	super(name, address, phone, email);
	}
}

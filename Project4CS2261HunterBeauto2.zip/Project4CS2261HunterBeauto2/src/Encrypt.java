import java.util.Scanner;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.FileNotFoundException;


/* Hunter Beauto
 * CS2261
 * Project 3
 * Encrypt
 */

public class Encrypt extends Main {
	
	
	public void setKey() {
		Scanner a = new Scanner(System.in);
		System.out.println("Enter the key(-128 to 127)");
		Key = a.nextByte();
	}
	
	public void setFileName() {
		Scanner b = new Scanner(System.in);
		System.out.println("Enter the new name for the File");
		FileNameTwo = b.nextLine();

	}
	
	public byte[] ConvertToByteArr(String inputFileName) {
		File file = new File(inputFileName);
		  //initialize array with file length
		  byte[] bytesArray = new byte[(int) file.length()]; 

		  try {
		  FileInputStream fis = new FileInputStream(file);
		  fis.read(bytesArray); //read file into bytes[]
		  fis.close();
		  } catch (IOException e) {
			  e.printStackTrace();
			  }
					
		  return bytesArray;
		
	}
	
	
	public String getFile() {
	    return FileNameTwo;
		
	}		
	
	public void Encryption(byte[] inputFileName, byte key) {
	    for(int i=0; i<inputFileName.length; i++)
	        inputFileName[i] = (byte) (inputFileName[i]+key);
	}
	
	public byte getKey() {
		return Key;	
	}
	public String FileNameTwo;
	public byte Key;

}

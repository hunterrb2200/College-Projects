import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;


public class Decrypt extends Main {
	
	
	//sets the key
	public void setKey() {
		System.out.println("Enter the key(-128 to 127)");
		Scanner a = new Scanner(System.in);
		System.out.println("Enter the key(-128 to 127)");
		Key = a.nextByte();
	}
	
	
	//get key if needed
	public byte getKey() {
		return Key;	
	}
	public void setFileName() {
		Scanner b = new Scanner(System.in);
		System.out.println("Enter the new name for the File");
		FileNameTwo = b.nextLine();

	}
	public byte[] ConvertToByteArr(String inputFileName) {
		File file = new File(inputFileName);
		  //init array with file length
		  byte[] bytesArray = new byte[(int) file.length()]; 

		  try {
		  FileInputStream fis = new FileInputStream(file);
		  fis.read(bytesArray); //read file into bytes[]
		  fis.close();
		  } catch (IOException e) {
			  e.printStackTrace();
			  }
					
		  return bytesArray;
		
	}
	
	//the method to decrypt
	public void decryption(byte[] inputFileName, byte key) {
	    for(int i=0; i<inputFileName.length; i++)
	        inputFileName[i] = (byte) (inputFileName[i]-key);
	}
	
	public String FileNameTwo;
	public byte Key;
	
	
	
	
}

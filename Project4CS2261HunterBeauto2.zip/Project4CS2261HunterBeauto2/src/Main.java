import java.util.Scanner;
import java.io.File;
import java.io.IOException; 
//import java.io.FileNotFoundException

/* Hunter Beauto
 * CS2261
 * Project 4
 * Main
 */
public class Main{	
	public static void main(String[] pArgs) throws IOException{

		int task;
		//user enter name of their file and opens file
		Scanner in = new Scanner(System.in);
	    System.out.println("What is the filename?");
	    inputFileName =in.next();
	    File file = new File(inputFileName);

	    
	    //buffered reader/writer needed?
	    try (Scanner scanner = new Scanner(file)) {
	        String line;
	        boolean hasNextLine = false;
	        while(hasNextLine = scanner.hasNextLine()) {
	          line = scanner.nextLine();
	          System.out.println(line);
	          }
	    }
		
	    //determines what the user wants to use
		Scanner a = new Scanner(System.in);
		System.out.println("If you would like to encrypt a file with a key press 1)");
		System.out.println("If you would like to decrypt a file with a key press 2)");
		System.out.println("If you would like to decrypt a file with an unkown key press 3)");
		task=a.nextInt();
		
		
		//for task 1
		if (task==1) {
			Encrypt en = new Encrypt();
			en.setKey();
			if (en.Key>127) {
				if (en.Key>-128) {
					en.setFileName();
					en.ConvertToByteArr(inputFileName);
					//en.Encryption(inputFileName, en.Key);
					return;
				}
				System.out.println("Error please restart)");
				return;
			}
		}
		
		//for task 2
		if (task==2) {
			Decrypt de = new Decrypt();
			de.setKey();
			if (de.Key>127) {
				if (de.Key>-128) {
					de.setFileName();
					de.ConvertToByteArr(inputFileName);
					//de.decryption(inputFileName, key);
					de.setFileName();
					return;
				}	
			System.out.println("Error please restart)");
			return;
			}
		}
		
		//for task 3 //wasnt able to bring it back in time
		//if (task==3) {
		
		//}
		if(task<1) {
			System.out.println("Error please restart)");
			return;
		}
		if(task>3) {
			System.out.println("Error please restart)");
			return;
		}
	}
	public static String inputFileName;
}

